AffiliateInfo
=============

.. autoclass:: telegram.AffiliateInfo
    :members:
    :show-inheritance: