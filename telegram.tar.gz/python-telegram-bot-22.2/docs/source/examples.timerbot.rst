``timerbot.py``
===============

.. literalinclude:: ../../examples/timerbot.py
   :language: python
   :linenos:
    