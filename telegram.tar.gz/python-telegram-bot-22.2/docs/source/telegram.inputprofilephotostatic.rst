InputProfilePhotoStatic
=======================

.. autoclass:: telegram.InputProfilePhotoStatic
    :members:
    :show-inheritance: