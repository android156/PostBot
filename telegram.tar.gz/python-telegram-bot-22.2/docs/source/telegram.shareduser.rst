SharedUser
==========

.. autoclass:: telegram.SharedUser
    :members:
    :show-inheritance:

