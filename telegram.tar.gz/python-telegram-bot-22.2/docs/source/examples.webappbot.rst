``webappbot.py``
================

.. literalinclude:: ../../examples/webappbot.py
   :language: python
   :linenos:

.. _webappbot-html:

HTML Page
---------

.. literalinclude:: ../../examples/webappbot.html
   :language: html
   :linenos:
    