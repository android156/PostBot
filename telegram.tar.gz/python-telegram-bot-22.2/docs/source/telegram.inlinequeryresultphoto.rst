InlineQueryResultPhoto
======================

.. autoclass:: telegram.InlineQueryResultPhoto
    :members:
    :show-inheritance:
