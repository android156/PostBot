PaidMediaPhoto
==============

.. autoclass:: telegram.PaidMediaPhoto
    :members:
    :show-inheritance:
