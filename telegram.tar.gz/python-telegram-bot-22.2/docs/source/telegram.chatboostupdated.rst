ChatBoostUpdated
================

.. versionadded:: 20.8

.. autoclass:: telegram.ChatBoostUpdated
    :members:
    :show-inheritance: