OwnedGifts
==========

.. autoclass:: telegram.OwnedGifts
    :members:
    :show-inheritance:
