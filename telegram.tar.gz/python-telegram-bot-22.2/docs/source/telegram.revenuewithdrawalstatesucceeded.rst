RevenueWithdrawalStateSucceeded
===============================

.. autoclass:: telegram.RevenueWithdrawalStateSucceeded
    :members:
    :show-inheritance:
