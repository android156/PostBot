UsersShared
===========

.. autoclass:: telegram.UsersShared
    :members:
    :show-inheritance:
