BackgroundTypeChatTheme
=======================

.. versionadded:: 21.2

.. autoclass:: telegram.BackgroundTypeChatTheme
    :members:
    :show-inheritance: