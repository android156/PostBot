GiveawayCreated
===============

.. autoclass:: telegram.GiveawayCreated
    :members:
    :show-inheritance: