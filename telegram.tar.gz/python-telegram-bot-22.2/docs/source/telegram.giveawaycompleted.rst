GiveawayCompleted
=================

.. autoclass:: telegram.GiveawayCompleted
    :members:
    :show-inheritance: