TransactionPartner
==================

.. autoclass:: telegram.TransactionPartner
    :members:
    :show-inheritance:
