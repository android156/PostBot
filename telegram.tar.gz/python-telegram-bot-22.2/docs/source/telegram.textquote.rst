TextQuote
=========

.. autoclass:: telegram.TextQuote
    :members:
    :show-inheritance:
