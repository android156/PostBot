UserChatBoosts
==============

.. versionadded:: 20.8

.. autoclass:: telegram.UserChatBoosts
    :members:
    :show-inheritance: