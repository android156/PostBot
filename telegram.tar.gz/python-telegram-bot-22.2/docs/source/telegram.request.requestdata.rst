RequestData
===========

.. autoclass:: telegram.request.RequestData
    :members:
    :show-inheritance: