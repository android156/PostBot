BusinessMessagesDeletedHandler
==============================

.. autoclass:: telegram.ext.BusinessMessagesDeletedHandler
    :members:
    :show-inheritance: