TransactionPartnerAffiliateProgram
===================================

.. autoclass:: telegram.TransactionPartnerAffiliateProgram
    :members:
    :show-inheritance: