PassportElementErrorUnspecified
===============================

.. autoclass:: telegram.PassportElementErrorUnspecified
    :members:
    :show-inheritance:
