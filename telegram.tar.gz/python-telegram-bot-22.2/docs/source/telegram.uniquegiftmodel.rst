UniqueGiftModel
===============

.. autoclass:: telegram.UniqueGiftModel
    :members:
    :show-inheritance:

