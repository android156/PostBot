UniqueGiftSymbol
================

.. autoclass:: telegram.UniqueGiftSymbol
    :members:
    :show-inheritance:

