PassportFile
============

.. autoclass:: telegram.PassportFile
    :members:
    :show-inheritance:
