``paymentbot.py``
=================

.. literalinclude:: ../../examples/paymentbot.py
   :language: python
   :linenos:
    