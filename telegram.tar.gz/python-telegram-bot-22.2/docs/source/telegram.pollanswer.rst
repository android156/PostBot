PollAnswer
==========

.. autoclass:: telegram.PollAnswer
    :members:
    :show-inheritance:
