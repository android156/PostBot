ProximityAlertTriggered
=======================

.. autoclass:: telegram.ProximityAlertTriggered
    :members:
    :show-inheritance:
