StoryAreaTypeLink
=================

.. autoclass:: telegram.StoryAreaTypeLink
    :members:
    :show-inheritance:
