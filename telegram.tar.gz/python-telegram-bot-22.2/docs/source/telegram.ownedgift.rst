OwnedGift
=========

.. autoclass:: telegram.OwnedGift
    :members:
    :show-inheritance:
