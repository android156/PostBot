UniqueGift
==========

.. autoclass:: telegram.UniqueGift
    :members:
    :show-inheritance:

