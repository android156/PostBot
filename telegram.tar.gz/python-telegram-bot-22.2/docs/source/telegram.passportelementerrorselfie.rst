PassportElementErrorSelfie
==========================

.. autoclass:: telegram.PassportElementErrorSelfie
    :members:
    :show-inheritance:
