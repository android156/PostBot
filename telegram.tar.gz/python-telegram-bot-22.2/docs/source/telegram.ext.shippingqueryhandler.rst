ShippingQueryHandler
====================

.. autoclass:: telegram.ext.ShippingQueryHandler
    :members:
    :show-inheritance:
