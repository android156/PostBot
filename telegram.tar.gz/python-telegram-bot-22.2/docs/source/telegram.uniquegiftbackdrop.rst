UniqueGiftBackdrop
==================

.. autoclass:: telegram.UniqueGiftBackdrop
    :members:
    :show-inheritance:

