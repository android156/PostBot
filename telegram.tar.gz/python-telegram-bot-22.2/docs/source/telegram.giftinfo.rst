GiftInfo
========

.. autoclass:: telegram.GiftInfo
    :members:
    :show-inheritance:

