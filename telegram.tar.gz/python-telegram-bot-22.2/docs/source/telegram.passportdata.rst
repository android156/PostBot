PassportData
============

.. autoclass:: telegram.PassportData
    :members:
    :show-inheritance:
