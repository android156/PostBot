ChatBoostSourceGiftCode
=======================

.. versionadded:: 20.8

.. autoclass:: telegram.ChatBoostSourceGiftCode
    :members:
    :show-inheritance: