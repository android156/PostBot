StoryArea
=========

.. autoclass:: telegram.StoryArea
    :members:
    :show-inheritance:
