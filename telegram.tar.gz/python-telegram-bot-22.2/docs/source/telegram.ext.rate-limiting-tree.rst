Rate Limiting
-------------

.. toctree::
    :titlesonly:

    telegram.ext.baseratelimiter
    telegram.ext.aioratelimiter