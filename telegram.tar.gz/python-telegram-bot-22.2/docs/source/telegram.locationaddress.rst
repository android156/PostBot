LocationAddress
===============

.. autoclass:: telegram.LocationAddress
    :members:
    :show-inheritance:
